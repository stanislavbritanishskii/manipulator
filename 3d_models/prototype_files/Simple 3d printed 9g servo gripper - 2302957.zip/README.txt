Simple 3d printed 9g servo gripper  by brunoip on Thingiverse: https://www.thingiverse.com/thing:2302957

Summary:
A simple 3d printed claw that I designed to be used with a 9g servo. It keeps the servo parallel to te claw action in order to reduce the weight in the arm.https://www.youtube.com/watch?v=FNFmIbqV8nc